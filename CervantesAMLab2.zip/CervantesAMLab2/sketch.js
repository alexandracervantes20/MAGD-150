function setup() {
  createCanvas(400, 400);
  background(180);
  
noStroke();
fill(255, 100, 150);
arc(40, 40,40, 40,PI, TWO_PI,PIE);
  
  //gb line
  stroke(300);
  strokeWeight(8);
  line(320, 290, 320, 380);
        triangle(320, 360, 310, 380, 330, 380);


  //Rb line
  stroke(300);
  strokeWeight(8);
  line(170, 170, 170, 280);
      triangle(170, 260, 160, 280, 178, 280);

  
  //Bb line
  stroke(300);
  strokeWeight(8);
  line(40, 20, 40, 200);
    triangle(40, 200, 30, 220, 50, 220);


  ////////////////////////

  colorMode(RGB, 0, 0, 0, 1);

  //Green Ballon.
  fill(0, 200, 0);
  stroke(0, 200, 0);
  ellipse(320, 220, 90,100);
  quad(310, 270, 330, 270, 315, 285,325, 285);



  //Red Ballon.
  fill(200, 0, 0);
  stroke(200, 0, 0);
  ellipse(170, 120, 90,100);
  quad(160, 170,180, 170,165, 185,175, 185);

  
  //Blue Ballon.
  fill(0, 0, 200);
  stroke(0, 0, 200);
  ellipse(40, 30, 90,100);
  quad(30, 80,50, 80,35, 95, 45, 95);
}

function draw() {
}