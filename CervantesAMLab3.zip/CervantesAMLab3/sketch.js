let x, y, d;
let c;
let a;
let pauseFrame;
 
function setup() {
createCanvas(400, 400);
 
x = 200;
y = 200;
d = 30;
 
c = 1;
a = 0;
pauseFrame = 0;
}
 
function draw() {
background(150);
 
fill(0);
rect(190, 1, 20, 200);
 
noStroke();
fill(71);
square(173, 165, 55);
square(173, 210, 55);
 
if (c == 1) {
fill(225, 0, 0);
}
 
if (c == 2) {
fill(0, 225, 0);
}
 
circle(x, y, d);
 
// use frameCount for movement
if (c == 2) {
a = (frameCount - pauseFrame) % (width + 70);
} else {
pauseFrame++;
}
 
fill(0, 100, 200);
circle(a, 200, 70);
}
 
function mouseClicked() {
if (dist(mouseX, mouseY, x, y) < d / 2) {
if (c == 2) {
c = 1;
} else {
c = 2;
}
}
}