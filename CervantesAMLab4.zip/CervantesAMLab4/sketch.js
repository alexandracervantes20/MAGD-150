let circleX;
let circleY;
let speedX=3;
let speedY=2;

function setup() {
  createCanvas(400, 400);
  background(100);
  circleX=random(0,400);
  circleY=random(0,400);
  

}

  
function draw(){
    background(100);
  circle(circleX,circleY,40);
  circleX+=speedX;
  circleY+=speedY;

  if (circleX-40 > width || circleX+40 < 0){
    circleX=random(0,400);
    speedX = random(2, 5) * (random() > 0.5 ? 1 : -1);  //random direction x
  }

  if (circleY-40 > height || circleY+40 < 0){
    circleY=random(0,400);
    speedY = random(1, 4) * (random() > 0.5 ? 1 : -1); //random direction y
  }

  
}